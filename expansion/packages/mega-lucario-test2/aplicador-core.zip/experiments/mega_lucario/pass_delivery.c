/* Layered RPBE01 delivery: preserve Snivy's accessor and every unrelated pass. */
typedef unsigned char u8;
typedef unsigned short u16;
typedef unsigned int u32;
#ifndef SNIVY_ACCESSOR
#error Missing audited preceding accessor
#endif
#define GET ((u32 (*)(void *,u32,u32))0x803DE52Cu)
#define SET ((void (*)(void *,u32,const u32 *))0x803DECA8u)
#define CTOR ((void (*)(void *,void *,const void *,void *,u32))0x8017D750u)
#define BASE_STATS ((void (*)(u32,void *))0x803E052Cu)
#define WORD(p) (*(volatile u32 *)(p))
#define HALF(p) (*(volatile u16 *)(p))
static volatile u32 busy;
static void zero(u8 *p,u32 n) { while(n--) *p++=0; }
static int ready(void) {
 u32 *stats=(u32 *)WORD(0x80625184u), *models=(u32 *)WORD(0x80625174u);
 u32 *faces=(u32 *)WORD(0x80625178u), *icons=(u32 *)WORD(0x806251D8u);
 u8 *row;
 if(!stats||!models||!faces||!icons||stats[0]<503||models[0]<672||faces[0]<503||icons[0]<564) return 0;
 row=(u8 *)stats[4]+502u*52u;
 if(HALF(row+24)!=21776||HALF(row+28)!=671||row[30]!=70||row[31]!=145||row[48]!=91) return 0;
 if(WORD((u8 *)models[4]+671u*72u+4)!=0x2001u) return 0;
 return ((void *(*)(u32))0x8024C32Cu)(0x2001u)!=0 && WORD(0x80453184u)!=0;
}
static int construct(u8 *out) {
 u32 ctx[64],trainer[64],party[16],i;
 u8 row[56],stats[44];
 const u16 moves[4]={418,370,396,182};
 zero((u8 *)ctx,sizeof(ctx));zero((u8 *)trainer,sizeof(trainer));zero((u8 *)party,sizeof(party));zero(row,sizeof(row));zero(out,0x8C);
 ctx[0x14/4]=6;ctx[0x60/4]=(u32)trainer;ctx[0x6C/4]=50;ctx[0x7C/4]=39;
 party[0xC/4]=0x01000000u;party[0x28/4]=0x13572468u^(502u<<8)^(50u<<16);
 BASE_STATS(502,stats);
 *(u16 *)(row+2)=0x1002;*(u16 *)(row+4)=1;*(u16 *)(row+6)=502;
 row[8]=stats[6];row[9]=stats[7];row[10]=4;row[12]=0;
 for(i=0;i<6;i++)row[16+i]=31;
 *(u16 *)(row+22)=508;row[24]=4;row[25]=128;row[27]=248;row[28]=128;
 for(i=0;i<4;i++)*(u16 *)(row+32+i*2)=moves[i];
 CTOR(ctx,out,row,party,255);
 /* Request a normal Mega. The existing mod grants a bonus to shinies; the
  * zeroed native trainer fixture otherwise makes this fixed set shiny.
  * Change only the secret trainer-ID half, preserving PID/nature and checksum. */
 {
  u32 pid=GET(out,0,0),ot=GET(out,7,0);
  if(((pid^(pid>>16)^ot^(ot>>16))&65535u)<8u) {
   ot^=0x00080000u;SET(out,7,&ot);
  }
 }
 if(GET(out,5,0)!=502||GET(out,160,0)!=50||GET(out,173,0)!=502||GET(out,10,0)!=91||GET(out,6,0)!=0) return 0;
 for(i=0;i<4;i++)if(GET(out,0x36+i,0)!=moves[i])return 0;
 return 1;
}
u32 mega_accessor(u32 address) {
 address=((u32 (*)(u32))SNIVY_ACCESSOR)(address);
 if(!busy && ready()) {
  u8 generated[0x8C];u8 *slot=(u8 *)WORD(0x80453184u)+37u*0x6ECu+0x1FCu;u32 i;
  busy=1;
  /* Only the original level-50 Ivysaur in the requested starter slot. */
  if(GET(slot,5,0)==2 && GET(slot,160,0)==50 && construct(generated)) {
   for(i=0;i<0x8C;i++)slot[i]=generated[i];
  }
  busy=0;
 }
 return address;
}

/* The pre-existing mod forces rental identities to look shiny and grants its
 * shiny stat bonus. Keep that policy for every old Pokemon, but use the native
 * PID/OT predicate for the newly delivered normal Mega so its agreed set stays
 * at 146/181/108/163/176/90. Naturally shiny Mega records still receive the bonus.
 */
u32 mega_appearance(void *mon) {
 if(GET(mon,5,0)==502) {
  u32 pid=GET(mon,0,0),ot=GET(mon,7,0);
  return ((u32 (*)(u32,u32))0x803DF75Cu)(ot,pid);
 }
 return ((u32 (*)(void *))0x8064D800u)(mon);
}
